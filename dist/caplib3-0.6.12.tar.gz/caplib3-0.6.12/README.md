# caplib3
NGS data analysis of capsid libraries

Work in progress, do not use unless you know what you are doing!

Installation: pip install caplib3

Run: python -m caplib3
